
import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


# --------------------------------------------------
# 1. LOAD KNOWLEDGE BASE
# --------------------------------------------------

with open("tradeiqx_knowledge.json", "r", encoding="utf-8") as file:
    knowledge_base = json.load(file)


# --------------------------------------------------
# 2. LOAD EMBEDDING MODEL
# --------------------------------------------------

model = SentenceTransformer("all-MiniLM-L6-v2")


# --------------------------------------------------
# 3. CREATE EMBEDDINGS
# --------------------------------------------------

texts = [item["content"] for item in knowledge_base]

embeddings = model.encode(
    texts,
    show_progress_bar=True
)


# --------------------------------------------------
# 4. SEMANTIC SEARCH
# --------------------------------------------------

def semantic_search(query, top_k=3):

    query_embedding = model.encode([query])

    similarities = cosine_similarity(
        query_embedding,
        embeddings
    )[0]

    top_indices = similarities.argsort()[::-1][:top_k]

    results = []

    for index in top_indices:

        result = knowledge_base[index].copy()

        result["similarity"] = float(
            similarities[index]
        )

        results.append(result)

    return results


# --------------------------------------------------
# 5. SMART SEARCH
# --------------------------------------------------

def smart_search(
    query,
    threshold=0.35,
    top_k=3
):

    results = semantic_search(
        query,
        top_k=top_k
    )

    filtered_results = [
        result
        for result in results
        if result["similarity"] >= threshold
    ]

    return filtered_results


# --------------------------------------------------
# 6. PERSONALIZED SEARCH
# --------------------------------------------------

def personalized_search(
    query,
    difficulty=None,
    threshold=0.35,
    top_k=3
):

    results = smart_search(
        query,
        threshold=threshold,
        top_k=top_k
    )

    if difficulty:

        filtered_results = [
            result
            for result in results
            if result["difficulty"].lower()
            == difficulty.lower()
        ]

        # If difficulty filtering removes everything,
        # return the original relevant results.
        if filtered_results:
            results = filtered_results

    return results


# --------------------------------------------------
# 7. BUILD RAG CONTEXT
# --------------------------------------------------

def build_rag_context(
    query,
    threshold=0.35,
    top_k=3
):

    results = smart_search(
        query,
        threshold=threshold,
        top_k=top_k
    )

    if not results:
        return "No relevant TradeIQX knowledge was found."

    context_parts = []

    for result in results:

        context_parts.append(
            f"Topic: {result['topic']}\n"
            f"Category: {result['category']}\n"
            f"Difficulty: {result['difficulty']}\n"
            f"Source: {result.get('source', 'TradeIQX Educational Knowledge Base')}\n"
            f"Similarity: {result['similarity']:.3f}\n"
            f"Content: {result['content']}"
        )

    return "\n\n---\n\n".join(context_parts)


# --------------------------------------------------
# 8. BUILD RAG CONTEXT WITH CONFIDENCE
# --------------------------------------------------

def build_rag_context_with_scores(
    query,
    threshold=0.35,
    top_k=3
):

    results = smart_search(
        query,
        threshold=threshold,
        top_k=top_k
    )

    if not results:

        return {
            "status": "no_match",
            "confidence": 0.0,
            "context": ""
        }

    best_score = float(
        results[0]["similarity"]
    )

    context_parts = []

    for result in results:

        context_parts.append(
            f"Topic: {result['topic']}\n"
            f"Category: {result['category']}\n"
            f"Difficulty: {result['difficulty']}\n"
            f"Similarity: {result['similarity']:.3f}\n"
            f"Content: {result['content']}"
        )

    return {
        "status": "success",
        "confidence": best_score,
        "context": "\n\n---\n\n".join(context_parts)
    }


print("TradeIQX Retriever loaded successfully!")
print("Knowledge entries:", len(knowledge_base))
